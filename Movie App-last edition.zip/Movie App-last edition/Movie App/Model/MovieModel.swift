//
//  MovieModel.swift
//  Movie App
//
//  Created by Ulan Kamai on 07.08.2021.
//

import Foundation

struct MovieModel: Decodable {
    let results:[Movie]
    
    struct Movie: Decodable {
        let id: Int
        let poster: String?
        let title: String?
        let releaseData: String?
        let rating: Double?
        
        enum CodingKeys: String, CodingKey {
            case id = "id"
            case poster = "poster_path"
            case title = "title"
            case releaseData = "release_date"
            case rating = "vote_average"
        }
        
    }
}
