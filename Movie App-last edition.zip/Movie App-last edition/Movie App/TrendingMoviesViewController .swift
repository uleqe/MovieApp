//
//  ViewController.swift
//  Movie App
//
//  Created by Ulan Kamai on 06.08.2021.
//

import UIKit

class TrendingMoviesViewController : UIViewController {

    @IBOutlet weak var tableView: UITableView!

    private let stringURL: String = "https://api.themoviedb.org/3/trending/movie/week"
    private let API_KEY = "8867184e58e73fc4b415e7044982d4d8"

    private var movies: [MovieModel.Movie] = []{
        didSet{
            tableView.reloadData()
        }
    }
    
    private var page: Int = 1
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(UINib(nibName: MovieCell.identifier, bundle: Bundle(for: MovieCell.self)), forCellReuseIdentifier: MovieCell.identifier)
        
        fetchTrendingMovies()
    }

}

extension TrendingMoviesViewController {
    private func fetchTrendingMovies(page: Int = 1) {
   var urlCompents = URLComponents (string: stringURL)
        urlCompents?.queryItems = [
            
            URLQueryItem(name: "api_key", value: API_KEY),
            URLQueryItem(name: "page", value: "\(page)")
        ]
        if let url = urlCompents?.url?.absoluteURL{
            URLSession.shared.dataTask(with: url) { data, response, error in
                if error != nil {
                    print ("Failed to fetch movies")
                    return
                    
                }
                DispatchQueue.global().async {
                    do {
                        if let data = data {
                            let results = try
                                 JSONDecoder().decode (MovieModel.self, from: data)
                           
                            DispatchQueue.main.async {
                                self.movies += results.results

                            }
                        }
                        } catch {
                            print(error)
                        }
                }

                    }.resume()
 
            }
    }
    


}


extension TrendingMoviesViewController: UITableViewDelegate{
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let currentOffset = scrollView.contentOffset.y
        let maximumOffset = scrollView.contentSize.height -
            scrollView.frame.size.height
        let deltaOffset = maximumOffset - currentOffset
        if deltaOffset <= 10 && currentOffset > 200 {
            page += 1
            fetchTrendingMovies(page: page)
            
        }
        
    }
}
extension TrendingMoviesViewController: UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return movies.count  
    
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: MovieCell.identifier, for: indexPath) as! MovieCell
        cell.movie = movies[indexPath.row]
    
        return cell
    }
    
      
}
