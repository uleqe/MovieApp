//
//  MovieCell.swift
//  Movie App
//
//  Created by Ulan Kamai on 07.08.2021.
//

import UIKit
import Kingfisher

class MovieCell: UITableViewCell {
    
    public static let identifier: String = "MovieCell"

    @IBOutlet private weak var posterImageView: UIImageView!
    
    @IBOutlet private  weak var movieTitleLabel: UILabel!
    
    @IBOutlet private weak var movieDateLabel: UILabel!
    @IBOutlet private weak var movieRatingLabel: UILabel!
    
    @IBOutlet private weak var movieRatingContainer: UIView!
    public var movie: MovieModel.Movie?{
        didSet{if let movie = movie {
            let posterURL = URL(string: "https://image.tmdb.org/t/p/w500\(movie.poster ?? "1")")
            posterImageView.kf.setImage(with: posterURL)
            movieRatingLabel.text = "\(movie.rating ?? 0)"
           movieTitleLabel.text = movie.title
           movieDateLabel.text = movie.releaseData
    }
        } }
    override func awakeFromNib() {
        super.awakeFromNib()
        posterImageView.layer.cornerRadius = 8
        posterImageView.layer.masksToBounds = true
        
        movieRatingContainer.layer.cornerRadius = 20
        movieRatingContainer.layer.masksToBounds = true

    }

    
    
}
